import { Fragment } from "react";
import "./App.css";
import { Route, Routes } from "react-router-dom";
import ProductList from "./pages/ProductList";
import ProductDetails from "./pages/ProductDetails";
import CartList from "./pages/CartList";
import Practice from "./pages/Practice";

function App() {
  return (
    <Fragment>
      <div>
        <h1>Shopping cart</h1>
        <Routes>
          <Route path="/products" element={<ProductList/>}/>
          <Route path="/product-details/:id" element={<ProductDetails/>}/>
          <Route path="/cart" element={<CartList/>}/>
          <Route path="/practice" element={<Practice/>}/>
        </Routes>
      </div>
    </Fragment>
  );
}

export default App;
