import { createContext, useEffect, useState } from "react";

export const ShoppingCartContext = createContext(null);

function ShoppingCartProvider({ children }) {
    const [productList, setProductList] = useState([]);
    const [loading, setLoading] = useState(true);

    async function fetchProductList() {
        const apiResponse = await fetch('https://dummyjson.com/products');
        const result = await apiResponse.json();
        console.log(result);
        
        if(result && result?.products) {
            setProductList(result?.products);
            setLoading(false);
        }
    }
    useEffect(() => {
        fetchProductList();
    }, [])
    console.log(productList);
    
  return (
    <ShoppingCartContext.Provider value={{productList, loading}}>
      {children}
    </ShoppingCartContext.Provider>
  );
}

export default ShoppingCartProvider;
