function CartList() {
  return (
    <div>
      <h1>Cart List Page</h1>
    </div>
  );
}

export default CartList;
