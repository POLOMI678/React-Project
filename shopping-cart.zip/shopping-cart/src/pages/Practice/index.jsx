function Practice() {
  return (
    <div>
      <h1>How are you? are you fine...?</h1>
    </div>
  );
}

export default Practice;
