import {
  Button,
  Card,
  CardActions,
  CardContent,
  Typography,
} from "@mui/material";

function TodoItem({ todo, fetchCurrentTodoDetails }) {
  console.log(todo);

  return (
    
      <Card
        sx={{
          maxWidth: 350,
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
        }}
      >
        <CardContent>
          <Typography variant="h4" color={"text-secondary"}>
            {todo?.todo}
          </Typography>
        </CardContent>
        <CardActions>
          <Button onClick={() => {fetchCurrentTodoDetails(todo?.id)}}
            sx={{
              backgroundColor: "black",
              color: "white",
              opacity: "0.7",
              "&:hover": {
                backgroundColor: "black",
                color: "white",
                opacity: "1",
              },
            }}
          >
            Details
          </Button>
        </CardActions>
      </Card>
    
  );
}

export default TodoItem;
